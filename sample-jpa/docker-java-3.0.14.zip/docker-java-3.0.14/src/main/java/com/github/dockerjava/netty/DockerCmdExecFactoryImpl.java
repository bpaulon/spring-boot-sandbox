package com.github.dockerjava.netty;

/**
 * @author Kanstantsin Shautsou
 * @deprecated old clashing name
 */
@Deprecated
public class DockerCmdExecFactoryImpl extends NettyDockerCmdExecFactory {
}
