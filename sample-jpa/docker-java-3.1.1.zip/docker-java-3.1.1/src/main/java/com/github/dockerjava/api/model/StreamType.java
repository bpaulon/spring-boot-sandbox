package com.github.dockerjava.api.model;

public enum StreamType {
    STDIN, STDOUT, STDERR, RAW
}
