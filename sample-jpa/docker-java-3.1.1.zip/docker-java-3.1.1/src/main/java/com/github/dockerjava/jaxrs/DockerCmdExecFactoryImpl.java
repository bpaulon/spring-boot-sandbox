package com.github.dockerjava.jaxrs;

/**
 * @author Kanstantsin Shautsou
 * @deprecated clashes with netty impl.
 */
@Deprecated
public class DockerCmdExecFactoryImpl extends JerseyDockerCmdExecFactory {
}
